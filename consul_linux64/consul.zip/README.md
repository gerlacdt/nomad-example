## Create your own consul.zip

```bash
# download consul_linux_64 binary in this directory and unzip it

# create custom zip-file with start.sh and ui-folder
zip -r consul.zip .
```
